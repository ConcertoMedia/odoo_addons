# -*- coding: utf-8 -*-
#################################################################################
#
#    Odoo, Open Source Management Solution
#    Copyright (C) 2021-today Botspot Infoware Pvt. Ltd. <www.botspotinfoware.com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#################################################################################
from odoo import api, fields, models, _


class ProjectTaskType(models.Model):
    _inherit = "project.task.type"

    employee_task_ids = fields.One2many("employee.task.schedule","employee_id", string="Employee task Schedule")
    employee_id = fields.Many2one('hr.employee',string='')

    #used for create new stage.
    @api.model
    def create(self, vals):
        empid = self.env['hr.employee'].search([])
        result = super(ProjectTaskType, self).create(vals)
        for value in empid:
            recordvals = {'stage_id': result.id, 'project_ids': result.project_ids, 'employee_id':value.id}
            rec = self.env['employee.task.schedule'].create(recordvals)
        return result

    #When changes in stage then it will call write.
    def write(self, vals):
        result = super(ProjectTaskType, self).write(vals)
        return result
