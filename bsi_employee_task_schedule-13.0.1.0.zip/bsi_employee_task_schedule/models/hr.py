# -*- coding: utf-8 -*-
#################################################################################
#
#    Odoo, Open Source Management Solution
#    Copyright (C) 2021-today Botspot Infoware Pvt. Ltd. <www.botspotinfoware.com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#################################################################################
from odoo import api, fields, models, _
from datetime import datetime, date, timedelta


class HrEmployee(models.Model):
    _inherit = "hr.employee"

    employee_task_ids = fields.One2many("employee.task.schedule", "employee_id", string="Employee task Schedule",compute='get_task_find')

    #when we create new employee then get all stages as a default of tasks.
    @api.model
    def default_get(self,fields):
        res = super(HrEmployee, self).default_get(fields)
        employee_task_ids = []
        value = self.env['project.task.type'].search([])
        for vals in value:
            rec = (0,0,{'stage_id':vals.id})
            employee_task_ids.append(rec)
        res.update({'employee_task_ids':employee_task_ids}) 
        return res

    #compute method used for employees
    def get_task_find(self):
        for rec in self:
            rec.employee_task_ids = False
            task_ids = self.env['project.task'].search([('user_id','=',rec.user_id.id)])
            stage_list = []
            for task_id in task_ids:
                if task_id.stage_id not in stage_list:
                    stage_list.append(task_id.stage_id)
            for stage in stage_list:
                task_list = []
                project_list = []
                for task in task_ids:
                    if task.stage_id.id == stage.id:
                        task_list.append(task.id)
                        if task.project_id not in project_list:
                            project_list.append(task.project_id.id)
                emp_schedule_dict = {'stage_id':stage.id,'employee_id':rec.id,'task_ids':[(6,0,task_list)],'project_ids':[(6,0,project_list)]}
                create_emp_schedule_dict = self.env['employee.task.schedule'].create(emp_schedule_dict)


class EmployeetaskSchedule(models.Model):
    _name = "employee.task.schedule"
    _description = "Employee task Schedule"

    employee_id = fields.Many2one('hr.employee',string='')
    stage_id = fields.Many2one('project.task.type',string='Stage')
    project_ids = fields.Many2many('project.project',string='Project')
    task_ids = fields.Many2many('project.task',string='Project Task')
