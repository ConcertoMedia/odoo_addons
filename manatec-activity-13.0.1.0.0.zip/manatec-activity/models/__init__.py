# -*- coding: utf-8 -*-
#  Author: Tobias Reinwarth (tobias.reinwarth@manatec.de)
#  Copyright: 2019, manaTec GmbH
#  Date created: 4.3.2019

from . import mail_activity
