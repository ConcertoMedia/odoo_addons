# Daniel Reis, 2014
# GNU Affero General Public License <http://www.gnu.org/licenses/>

from . import project_task
from . import project_task_type
