This module adds a basic Qweb report to the tasks of Project Management App.
The report has two versions: one with only the task information and
another including the chatter messages as well.
