To use this module, you need to:

#. Go to 'Project > Tasks' and open a task.
#. Click 'Print > Print Task' or 'Print > Print Task and Chatter'.
