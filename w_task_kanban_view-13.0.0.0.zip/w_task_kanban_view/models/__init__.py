# -*- coding: utf-8 -*-

from . import inherit_project_task  # noqa
from . import inherit_project_task_type  # noqa
