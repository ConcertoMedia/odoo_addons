Project Task Timer v13
======================================
Task Timer with Start & Stop 

Installation
============
	- www.odoo.com/documentation/13.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Jesni Banu v10 @ cybrosys, Contact: odoo@cybrosys.com
	       Kavya Raveendran v11 @ cybrosys, Contact: odoo@cybrosys.com
	       Kavya Raveendran v12 @ cybrosys, Contact: odoo@cybrosys.com
           Sreejith sasidharan v13 @ cybrosys, Contact: odoo@cybrosys.com
