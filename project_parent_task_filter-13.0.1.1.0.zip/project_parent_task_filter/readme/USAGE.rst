To use this module, you need to:

#. Select the filter or the filter group Parent tasks in a Project
