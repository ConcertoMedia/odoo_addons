* `C2i Change 2 improve <http://c2i.es/>`_:

  * Eduardo Magdalena <emagdalena@c2i.es>

* Stephan Keller <MiStK@gmx.de>
