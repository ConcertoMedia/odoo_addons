This module adds a filter to show only the parent tasks in a project and
a group to sort tasks by its parent tasks.
It also adds the subtask number in the kanban view and activates the use
of subtasks in the project settings.
